# Handoff: Rose Noire — B2B landing page

## Overview
A single-page, conversion-focused landing for **Rose Noire**, a florist workshop in Ixelles (Brussels), aimed at companies: offices, hotels, restaurants, event agencies. There is one goal: getting visitors to request a quote (the `#devis` form). All copy is in French.

## About the design files
`Rose Noire B2B.dc.html` is a **design reference built in HTML**. It shows the intended look and behavior; it is not production code. Rebuild it in the target codebase's stack (e.g. Next.js/React, Astro, WordPress block theme) using that stack's patterns. If there is no codebase yet, pick an appropriate framework (Astro or Next.js + Tailwind is a good fit for a static marketing page with one form).
Open the file in a browser to view it. Keep `support.js` and `image-slot.js` next to it. They are prototype-runtime helpers only, so don't port them.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, copy and interactions are final. Recreate them pixel-accurately.

## Global layout
- Content container: `max-width: 1200px; margin: 0 auto; padding-inline: clamp(20px, 4vw, 40px)`.
- Section vertical padding: `clamp(72px, 10vw, 128px)`. Dark sections (Why, Devis) use `clamp(80px, 11vw, 140px)`.
- Section background sequence: White hero → Forest marquee → White offers → Forest "why" → White réalisations → Linen Mist method → White proof → Fog FAQ → Forest devis → White footer.
- All grids use `repeat(auto-fit, minmax(min(100%, Npx), 1fr))`, so they collapse to one column on mobile. No fixed widths.
- Anchored sections have `scroll-margin-top: 72px` (sticky header). `html { scroll-behavior: smooth }`.
- Shapes: buttons, tags and nav segments are pills (`9999px`). Large cards are `28px`, card images `20px`, inputs `10px`, the floating hero card `20px`.
- Flat design. The only shadows are listed under Tokens.

## Sections / components

### 1. Header (sticky)
- `position: sticky; top: 0; z-index: 40`, white, `border-bottom: 1px solid rgba(14,15,12,.08)`, height 72px. Flex space-between, gap 16px.
- Left: brand link to `#top`. A 14px circle in `#ff8fab`, then "Rose Noire" in Bricolage Grotesque 800 / 26px / `-0.04em` / `#163300`, `nowrap`.
- Center (viewport ≥ 900px only): pill nav. Container `#e8ebe6`, radius 9999, padding 4, gap 4. Links: "Offres" `#offres`, "Réalisations" `#realisations`, "Méthode" `#methode`, "FAQ" `#faq`. Each link: padding 8/16, Geist 500 / 15px / `#163300`, hover bg `#fff`.
- Right: the phone link "+32 475 61 44 58" (`tel:0032475614458`, 15px/500) shows only at ≥ 1100px. The CTA pill "Demander un devis" always shows: bg `#9fe870`, text `#163300`, padding 11/22, 15px/600, hover bg `#8fdc5e`.

### 2. Hero (`#top`)
Two-column auto-fit grid (`minmax(min(100%,460px),1fr)`), gap `clamp(40px,6vw,72px)`, items centered. Padding `clamp(40px,7vw,96px) 0 clamp(56px,8vw,112px)`.
**Left column** (flex column, gap 28, flush left):
- Tag pill: bg `#e2f6d5`, text `#163300`, padding 8/14, 14px/500. Contains an 8px dot in `#163300` and the text "Fleuriste pour entreprises · Bruxelles".
- H1: "Des fleurs qui font **forte** impression." Bricolage Grotesque 800, `clamp(54px,7.2vw,104px)`, line-height .9, `-0.045em`, `#0e0f0c`, `text-wrap: balance`. The word "forte" sits on a lime highlight: bg `#9fe870`, color `#163300`, padding `0 .12em`, radius `.18em`, `box-decoration-break: clone`.
- Lead paragraph: `clamp(18px,1.6vw,21px)`, lh 1.5, max-width 520, `#454745`. Text: "Abonnements floraux, événements et cadeaux d'affaires pour bureaux, hôtels et restaurants. Composés dans notre atelier d'Ixelles, livrés et renouvelés partout à Bruxelles."
- CTA row (wrap, gap 24):
  - Primary pill "Recevoir mon devis sous 24h" → `#devis`. bg `#9fe870`, text `#163300`, 17px/600, padding `16px 16px 16px 28px`. It ends in a 32px `#163300` circle holding a lime Lucide `arrow-right` (18px). Hover bg `#8fdc5e`.
  - Text link "Voir nos réalisations" → `#realisations`. 17px/500, underline, offset 4px.
- Reassurance row (wrap, gap 10/22): three items, each a Lucide `check` (18px, stroke 2.4) plus text, 15px/500, `#163300`: "Sans engagement", "Livraison & installation incluses", "Plus de 10 ans à Ixelles".

**Right column** (visual collage, `position: relative`, height `clamp(440px,48vw,620px)`):
- Main photo: absolute top-right, 80% × 84%, radius 28.
- Circle photo: absolute bottom-left, width 42%, `aspect-ratio: 1`, inside an 8px white ring.
- "Next delivery" card: absolute `top: 9%; left: 0`. White, radius 20, padding 18/20, min-width 230, shadow `0 6px 20px rgba(0,0,0,.08), 0 0 0 1px rgba(14,15,12,.08)`. Contents:
  - Line 1: an 8px `#9fe870` dot with a 3px `#e2f6d5` ring, then "Prochaine livraison" (13px/500, `#6a6c6a`).
  - Line 2: "Mardi · 8h30" (Bricolage 800, 26px, `-0.03em`, `#0e0f0c`).
  - Line 3: "Hall d'accueil — composition de saison" (14px).
- Badge: absolute `right: 6%; bottom: 4%`. bg `#163300`, text `#9fe870`, pill, padding 12/20, 14px/600. It opens with an 8px `#ff8fab` dot, then "Livré jusqu'à la Maison Blanche".

### 3. Sector marquee (toggleable)
- Band: bg `#163300`, padding 30px 0, overflow hidden.
- Moving track: an infinite horizontal loop. The content is duplicated twice, and the animation is `translateX(0 → -50%)`, 48s linear infinite.
- Words: "Bureaux, Hôtels, Restaurants, Showrooms, Séminaires, Cabinets, Galas, Agences, Réceptions". Bricolage 800, `clamp(36px,4.4vw,60px)`, `-0.04em`, `#9fe870`.
- Separators between words: 14px circles alternating `#ffffff` / `#ff8fab`. Gap 40.
- Respect `prefers-reduced-motion` in production (pause the animation).

### 4. Offres (`#offres`)
- Header row: space-between, wraps.
  - Left: kicker "NOS OFFRES" (14px/600, uppercase, `0.08em`, `#054d28`), then H2 "Une offre pour chaque moment de votre entreprise." (Bricolage 800, `clamp(40px,5.4vw,72px)`, lh .95, `-0.04em`, `#0e0f0c`, max-width 760).
  - Right: paragraph (18px, max-width 340): "Du hall d'accueil au gala de fin d'année, un seul atelier pour toutes vos fleurs."
- Cards grid: `minmax(min(100%,262px),1fr)`, gap 16. Header-to-grid gap is 56.
- Card structure: radius 28, padding 10, flex column. Image 220px tall, radius 20. Body padding `22px 16px 16px`, gap 12.
  - Title: Bricolage 800, 28px, `-0.03em`.
  - Text: 16px, lh 1.5.
  - Link "Demander un devis →": underlined label plus a 16px arrow, 600.
  - Clicking the link sets the form's "need" to that card's offer, then scrolls to `#devis`.

| # | Background | Title color | Title | Copy | Extra |
|---|---|---|---|---|---|
| 1 | `#e2f6d5` | `#163300` | Abonnement floral | Des compositions fraîches à l'accueil, en salle de réunion ou en salle de restaurant, renouvelées chaque semaine ou tous les quinze jours. | Tag "Le plus demandé" at top-left of the image (lime bg, `#163300`, 12px/600) |
| 2 | `#e8ebe6` | `#163300` | Événements | Séminaires, lancements, galas, inaugurations : une scénographie florale à la hauteur de votre marque, montée et démontée par nos soins. | — |
| 3 | `#fde4ea` | `#163300` | Cadeaux d'affaires | Bouquets et plantes pour remercier clients, partenaires et équipes. Commande groupée, carte personnalisée, livraison planifiée. | — |
| 4 | `#054d28` | `#9fe870` | Décor végétal | Plantes vertes, fleurs séchées et artificielles haut de gamme, pour les espaces où l'entretien doit rester minimal. | Body text `#e2f6d5`, link `#fff` (hover lime) |

### 5. Why us (dark)
- Background `#163300`.
- Header row: H2 "Zéro gestion. Toujours frais." (Bricolage 800, `clamp(52px,8vw,112px)`, lh .88, `-0.045em`, `#9fe870`, max-width 760). Next to it, a paragraph (19px, `#d9e8cf`, max-width 380): "Vous validez une fois. Nous nous occupons du reste, semaine après semaine, sans que vous ayez à y penser."
- Four columns: `minmax(min(100%,240px),1fr)`, gap `40px 32px`. Header-to-columns gap is 72.
- Each column: top border `1px solid rgba(159,232,112,.35)`, padding-top 28, gap 16.
  - Icon: 52px circle, bg `#054d28`, lime Lucide icon at 24px.
  - H3: 22px/600, `#fff`.
  - Text: 16px, lh 1.55, `#d9e8cf`.

| Icon | Title | Text |
|---|---|---|
| user-round | Une interlocutrice unique | Sophie, fleuriste fondatrice, suit votre compte du premier brief à chaque livraison. |
| truck | Livré, installé, renouvelé | Nous passons, remplaçons et repartons avec l'ancienne composition. Vous n'avez rien à faire. |
| refresh-cw | Fraîcheur garantie | Une composition fatigue avant son heure ? Nous la remplaçons, sans discussion. |
| file-text | Facturation simple | Un devis clair, une facture mensuelle, aucun frais caché. |

### 6. Réalisations (`#realisations`)
- Kicker "RÉALISATIONS" and H2 "Ce que nous composons pour nos clients." (same styles as Offres).
- Gallery grid: `minmax(min(100%,270px),1fr)`, `grid-auto-rows: 260px`, gap 16. The first tile spans 2 rows.
- Tiles: radius 28, image as `object-fit: cover`.
- Caption pill at top-left 16/16: white, `#163300`, padding 8/14, 13px/600.
- Captions, in order: "Atelier · Ixelles", "Événement · Composition", "Décor · Fleurs séchées", "Réception · Mariage", "Livraison · Bureaux".

### 7. Méthode (`#methode`)
- Background `#e2f6d5`.
- Header row:
  - Kicker "MÉTHODE", then H2 "Trois étapes, et c'est fleuri."
  - Right: pill "Commencer par l'étape 1" → `#devis`. bg `#163300`, text `#9fe870`, padding 14/24, 16px/600, hover bg `#054d28`.
- Steps grid: `minmax(min(100%,300px),1fr)`, gap 16.
- Step cards: radius 28, padding 32, min-height 300, flex column.
  - Big number: Bricolage 800, 96px, lh .85, `-0.05em`.
  - Flexible spacer.
  - H3: 24px/600.
  - Text: 16px.
- Card content:
  - Card 01 (white, number `#163300`): "Un échange de 15 minutes" — "Vos espaces, votre image, votre budget. Par téléphone ou directement sur place."
  - Card 02 (white): "Une proposition sur mesure" — "Moodboard, rythme de livraison et devis détaillé, envoyés sous 48 heures."
  - Card 03 (bg `#163300`, number `#9fe870`, title `#fff`, text `#d9e8cf`): "La première livraison" — "Nous installons, vous profitez. Rythme et style ajustables à tout moment."

### 8. Proof
Two-column grid: `minmax(min(100%,440px),1fr)`, gap 16.
**Left card** (bg `#163300`, radius 28, padding 10):
- Photo: height `clamp(260px,30vw,360px)`, radius 20.
- Body: padding `32px 26px 26px`.
  - H2: "Jusqu'à la Maison Blanche." (Bricolage 800, `clamp(40px,4.6vw,60px)`, `#9fe870`).
  - Paragraph (18px, `#fff`): "Rose Noire a eu l'honneur de livrer ses bouquets à la Maison Blanche. La même exigence, pour votre hall d'accueil."

**Right column** (stack, gap 16):
- Stat card: bg `#9fe870`, radius 28, padding 32. "10+" in Bricolage 800 at `clamp(72px,8vw,112px)`, `#163300`, followed by "ans d'atelier au cœur d'Ixelles, rue Américaine." (18px/500, max-width 220).
- Testimonial 1: bg `#e8ebe6`, radius 28, padding 28/32. Quote (20px, `#0e0f0c`): « Sophie est une fleuriste super créative ! De plus, la qualité de ses fleurs est irréprochable. » Attribution (14px/500, `#6a6c6a`): "Thomas — avis City Plug".
- Testimonial 2: bg `#fde4ea`, same styles. Quote: « La meilleure fleuriste de Bruxelles ! Rapport qualité, créativité et prix. » Attribution: "Patrick Menache — avis City Plug".

### 9. FAQ (`#faq`)
- Background `#e8ebe6`. Two-column grid (`minmax(min(100%,380px),1fr)`), gap `48px 72px`.
- Left column:
  - Kicker "FAQ".
  - H2 "Questions fréquentes".
  - Paragraph: "Une autre question ? Appelez Sophie au **+32 475 61 44 58**." The number is a tel link.
- Right column: an accordion. Rows have a `1px solid #c9cfc5` top border; the last row also has a bottom border.
  - Question button: full width, padding 24px 0, 20px/600, `#0e0f0c`.
  - Toggle icon: a 36px white circle with a Lucide `plus`. It rotates 45° when open (`transition: transform .25s`).
  - Answer: 17px, lh 1.55, `padding: 0 56px 24px 0`.
  - Only one item is open at a time. Item 1 is open by default; clicking the open item closes it.
- Questions and answers:
  1. Y a-t-il un engagement minimum ? — Non. Nos abonnements sont sans engagement de durée : vous ajustez le rythme ou mettez en pause quand vous le souhaitez.
  2. Quelles zones livrez-vous ? — Les 19 communes de Bruxelles et la périphérie proche. Pour un événement hors zone, parlons-en : nous trouvons une solution.
  3. Quel budget prévoir ? — Tout dépend de la taille des compositions et du rythme. Après un échange de 15 minutes, vous recevez un devis détaillé, sans surprise.
  4. Pouvez-vous suivre notre charte graphique ? — Oui. Couleurs, matières, style : nous composons à partir de votre identité pour que chaque bouquet prolonge votre marque.
  5. Comment se passe la facturation ? — Une facture mensuelle unique pour les abonnements, une facture par projet pour les événements et les cadeaux.

### 10. Devis / quote form (`#devis`) — the conversion target
Background `#163300`. Two-column grid (`minmax(min(100%,420px),1fr)`), gap 56.

**Left column** (gap 28):
- Tag: bg `#054d28`, text `#9fe870`, with a lime dot: "Réponse sous 24h ouvrées".
- H2 "Parlons de vos fleurs.": Bricolage 800, `clamp(56px,8vw,112px)`, lh .88, `#9fe870`.
- Paragraph (19px, `#fff`, max 440): "Décrivez votre besoin en une minute. Sophie vous rappelle avec une première proposition, sans engagement."
- Contact list (max 440). Each row is split into a label and a value, with rules `1px solid rgba(159,232,112,.3)`:
  - "Téléphone" | "+32 475 61 44 58" (a tel link, 20px/600, hover lime).
  - "Atelier" | "Rue Américaine 160, 1050 Ixelles".
- Labels are 14px `#d9e8cf`.

**Right: form card** (white, radius 28, padding `clamp(24px,4vw,40px)`, gap 28):
- **Votre besoin**: single-select pills: Abonnement floral (default) / Événement / Cadeaux d'affaires / Décor végétal.
  - Pill: padding 10/18, 15px/500.
  - Inactive: bg `#fff`, text `#163300`, `inset 0 0 0 1px #c5cbc1`.
  - Active: bg `#163300`, text `#9fe870`.
- **Budget indicatif** (only in "Qualifié" mode): single-select pills with the same styling: Moins de 250 € / 250 – 600 € / Plus de 600 € / À définir (default).
- **Fields**: 2-column auto-fit grid (`minmax(min(100%,200px),1fr)`), gap 16.
  - Label: 14px/500, `#0e0f0c`.
  - Input: 16px, padding 13/16, radius 10, border `1px solid #868685`. Focus: border `#163300` + `0 0 0 1px #163300`, no glow. Error: border `#cb272f`.
  - Nom * (placeholder "Marie Dubois")
  - Entreprise ("Hôtel, cabinet, agence…")
  - E-mail professionnel * ("marie@entreprise.be")
  - Téléphone ("+32 …")
- **Textarea** (only in "Qualifié" mode): "Vos espaces, vos envies (optionnel)", 3 rows, placeholder "Ex. : un grand bouquet à l'accueil et trois petites compositions en salles de réunion."
- **Error line**: 14px/500, `#cb272f`.
- **Submit**: full-width lime pill "Recevoir ma proposition". The label sits flush left, and a 36px forest circle with a lime arrow sits on the right. Padding `14px 14px 14px 28px`, 17px/600.
- Microcopy under the button (13px, `#6a6c6a`): "Sans engagement · Vos données ne sont jamais partagées."

**Success state** (replaces the form):
- A 72px lime circle with a check icon.
- H3 "Merci {prénom}, c'est noté." (Bricolage 800, `clamp(36px,4vw,52px)`).
- Text: "Sophie revient vers vous sous 24h ouvrées avec une première proposition."
- Tag "Besoin : {need}" (bg `#e2f6d5`).
- Underlined text button "Envoyer une autre demande", which resets the form.

### 11. Footer
- White, padding `clamp(64px,8vw,96px) 0 32px`.
- Four info columns (`minmax(min(100%,220px),1fr)`). Headings are 14px/600 `#0e0f0c`; body is 16px/lh 1.6.
  - Atelier: "Rue Américaine 160 / 1050 Ixelles, Bruxelles".
  - Horaires: "Mar – ven : 12h – 19h30 / Sam : 10h30 – 19h30 · Dim : 10h30 – 17h".
  - Contact: phone and a "Demander un devis" link.
  - Langue: FR pill (active: `#163300` bg, lime text) and NL pill (outlined, links to `https://rose-noire.be/nl/home/`).
- Giant wordmark "Rose Noire": Bricolage 800, `clamp(72px,17vw,232px)`, lh .8, `-0.055em`, `#163300`, nowrap.
- Bottom bar: border-top `1px solid #e8ebe6`, 13px, `#6a6c6a`. Left: "© 2026 Rose Noire — Fleuriste pour entreprises à Bruxelles". Right: "Bureaux · Hôtels · Restaurants · Événements".

### 12. Floating CTA (toggleable)
- `position: fixed; right: 20px; bottom: 20px; z-index: 50`.
- Pill in `#163300` with lime text "Devis gratuit en 24h" (15px/600), padding `8px 8px 8px 20px`. It ends in a 34px lime circle with a forest arrow.
- Shadow `0 10px 32px rgba(0,0,0,.15)`, hover bg `#054d28`. Links to `#devis`.
- In production, consider hiding it while `#devis` is in view.

## Interactions & behavior
- All CTAs are anchor links to `#devis`, with smooth scrolling.
- Offer-card links preselect the form's "need" before scrolling.
- Form validation on submit:
  - `name` is required ("Indiquez votre nom.").
  - `email` must match `/^\S+@\S+\.\S+$/` ("Indiquez une adresse e-mail valide.").
  - A field's error clears as soon as the user edits that field.
  - Errors show as a single red line above the submit button, and the failing inputs get a red border.
- On a valid submit, show the success state. **The prototype does not send anything.** Wire it to a real endpoint (email service, CRM, Formspree, etc.) and add loading and failure states. Recommended: a honeypot/anti-spam field, a GDPR consent line, and analytics events for `cta_click` and `lead_submit`.
- FAQ: single-open accordion.
- Responsive:
  - Grids reflow through auto-fit.
  - Header: nav hidden below 900px, phone hidden below 1100px.
  - Hero collage keeps percentage positions; its height is `clamp(440px,48vw,620px)`.

## State
- `need`: one of the 4 offers.
- `budget`: one of the 4 ranges.
- `form`: `{ name, company, email, phone, message }`.
- `errors`.
- `sent`: boolean.
- `faqOpen`: index, or -1.

## Configurable options (prototype tweaks)
- `formMode`: "Qualifié" (with budget and message) or "Court" (the need plus the 4 fields). Default: Qualifié.
- `showFloating`: floating CTA. Default: true.
- `showMarquee`: sector marquee. Default: true.

## Design tokens
**Colors**
- Forest Ink `#163300`: primary dark surfaces, text on light backgrounds.
- Lime `#9fe870`: primary CTA fill, active states, display type on dark backgrounds. Hover `#8fdc5e`. Never use it as text on light backgrounds.
- Spruce `#054d28`: secondary dark (icon circles, card 4, hovers, kickers).
- Linen Mist `#e2f6d5`: pale green surfaces.
- Fog `#e8ebe6`: grey-green surfaces.
- Rose pale `#fde4ea` and Rose `#ff8fab`: decorative accent (dots, one card, one testimonial).
- Obsidian `#0e0f0c`: headings.
- Charcoal `#454745`: body text.
- Slate `#6a6c6a`: meta text.
- Pebble `#868685`: input borders.
- Divider `#c9cfc5`, pill border `#c5cbc1`.
- On-dark text `#d9e8cf`.
- Error `#cb272f`.

**Typography**
- Display: **Bricolage Grotesque** 800 (Google Fonts, `opsz 12..96`), with tight tracking from `-0.03em` to `-0.055em` and line-height .8–.95.
- UI/body: **Geist** 400/500/600/700.
- Body sizes: 13, 14, 15, 16, 17, 18, 19/20, 21px.
- Headings: H3 22–28px. H2 `clamp(40px,5.4vw,72px)`. Hero and dark-section H2s go up to 104–112px.

**Radii:** pill 9999 · large card 28 · image and floating card 20 · input 10.

**Shadows (only these):**
- Floating card: `0 6px 20px rgba(0,0,0,.08), 0 0 0 1px rgba(14,15,12,.08)`.
- Floating CTA: `0 10px 32px rgba(0,0,0,.15)`.

**Spacing:** 4px base. Common gaps are 8, 12, 16, 24, 28, 32, 40, 48, 56 and 72.

## Assets
- **Photos:** hot-linked from the client's current site `rose-noire.be/wp-content/uploads/...` (the URLs are in the HTML `src` attributes). Replace them with high-resolution originals from the client, served locally and optimized (AVIF/WebP, `srcset`). Placeholders in the prototype are drag-and-drop slots; production should use plain `<img>` or a framework image component with `object-fit: cover`.
- **Icons:** Lucide (`arrow-right`, `check`, `plus`, `user-round`, `truck`, `refresh-cw`, `file-text`). Use the `lucide-react` package or an equivalent.
- **Fonts:** Google Fonts (Bricolage Grotesque, Geist). Self-host them in production.

## Copy to confirm with the client
These promises were written for the design and must be validated before launch:
- "réponse sous 24h"
- "sans engagement"
- "livraison & installation incluses"
- "fraîcheur garantie"
- the budget ranges
- all FAQ answers

## Files
- `Rose Noire B2B.dc.html`: the full design reference (open it in a browser).
- `support.js`, `image-slot.js`: prototype runtime only, not for production.
